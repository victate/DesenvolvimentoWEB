from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_POST
from .carrinho import Carrinho
from arremate.models import Produto, Imagem
from .forms import FormularioParaAdicaoDeProdutosAoCarrinho
from django.core.paginator import Paginator
from django.utils import six

@require_POST

def adicionar_ao_carrinho(request, id_produto):
    carrinho = Carrinho(request)
    produto = get_object_or_404(Produto, produto_id=id_produto)
    form = FormularioParaAdicaoDeProdutosAoCarrinho(request.POST)
    if form.is_valid():
        cd = form.cleaned_data
        carrinho.adicionar(produto=produto,
                 quantidade=cd['quantidade'],
                 atualiza_quantidade=cd['atualizar'])
    return redirect('carrinho:detalhes_do_carrinho')

def detalhes_do_carrinho(request):
    logo = Imagem.objects.get(imagem_id=1)
    carrinho = Carrinho(request)
    itens_cart = carrinho.__len__()
    if itens_cart == 0:
        itens_cart = "Carrinho de Compras"

    lista = carrinho.get_lista_de_itens_de_carrinho()
    for item in lista:
        item['atualizar_quantidade_form'] = FormularioParaAdicaoDeProdutosAoCarrinho(
            initial={'quantidade': item['quantidade'], 'atualizar': True})
    return render(request, 'carrinho/exibe.html', {'carrinho': carrinho, 'lista': lista, 'logo': logo,"itens_cart":itens_cart})

def remover_do_carrinho(request, id_produto):
    carrinho = Carrinho(request)
    produto = get_object_or_404(Produto, produto_id=id_produto)
    carrinho.remover(produto)
    return redirect('carrinho:detalhes_do_carrinho')

def limpar_carrinho(request, id_produto):
    carrinho = Carrinho(request)
    carrinho.limpar()
    return redirect('carrinho:detalhes_do_carrinho')

