from django.apps import AppConfig


class CarrinhoConfig(AppConfig):
    name = 'carrinho'
