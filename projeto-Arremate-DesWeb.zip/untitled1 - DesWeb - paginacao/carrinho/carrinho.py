from decimal import Decimal
from django.conf import settings
from arremate.models import Produto, PNormal, Foto

class Carrinho(object):

    def __init__(self, request):
        self.session = request.session
        self.carrinho = self.session.get(settings.CARRINHO_SESSION_ID)

        if not self.carrinho:
            self.carrinho = self.session[settings.CARRINHO_SESSION_ID] = {}

    def __len__(self):
        return sum(item['quantidade'] for item in self.carrinho.values())

    def get_lista_de_itens_de_carrinho(self):
        lista = []
        for item in self.carrinho.values():
            produto = Produto.objects.get(produto_id=item['id'])
            foto = Foto.objects.get(produto_id=item['id'])
            lista.append({'id': item['id'],
                          'quantidade': item['quantidade'],
                          'foto' : foto.figura,
                          'preco': Decimal(item['preco']),
                          'preco_total': item['quantidade'] * Decimal(item['preco']),
                          'produto': produto})
        return lista

    def adicionar(self, produto, quantidade=1, atualiza_quantidade=False):
        produto_id = str(produto.produto_id)

        if produto_id not in self.carrinho:
            preco = PNormal.objects.get(produto_id=produto_id).preco
            self.carrinho[produto_id] = {'id': produto_id, 'quantidade': 0, 'preco': str(preco)}

        if atualiza_quantidade:
            self.carrinho[produto_id]['quantidade'] = quantidade
        else:
            self.carrinho[produto_id]['quantidade'] += quantidade

        self.salvar()

    def remover(self, produto):
        produto_id = str(produto.produto_id)
        if produto_id in self.carrinho:
            del self.carrinho[produto_id]
            self.salvar()

    # Nós utilizamos o id do produto como chave no carrinho. Convertemos o ID do produto em um string uma vez que o
    # Django utiliza JSON para serializar dados da sessão e o JSON apenas permite strings. O ID do produto é a chave
    # e o valor que persistimos é um dicionário com quantidade e preço para o produto. O preço do produto é convertido
    # de decimal em string para ser serializado. Finalmente, chamamos o método salvar para salvar o carrinho na sessão.
    # O método salvar salva na sessão todas as mudanças efetuadas no carrinho e marca a sessão como modificada
    # utilizando session.modified = true. Isto diz ao Django que a sessão foi modificada e que necessita ser salva.

    def salvar(self):
        # atualiza o carrinho na sessão
        self.session[settings.CARRINHO_SESSION_ID] = self.carrinho

        # marca a sessão como "modificada" para ter certeza que ela será salva


    def limpar(self):
        self.session[settings.CARRINHO_SESSION_ID] = {}
        self.session.modified = True

    def get_preco_total(self):
        return sum(Decimal(item['preco']) * item['quantidade'] for item in self.carrinho.values())
