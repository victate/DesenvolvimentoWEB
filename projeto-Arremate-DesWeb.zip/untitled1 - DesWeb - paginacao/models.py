# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from __future__ import unicode_literals

from django.db import models
from django.urls import reverse


class Produto(models.Model):
    produto_id = models.IntegerField(primary_key=True)
    nome = models.CharField(max_length=60, blank=True, null=True)
    descricao = models.CharField(max_length=180, blank=True, null=True)
    loja = models.ForeignKey(Loja, blank=True, null=True)
    tamanho = models.IntegerField(blank=True, null=True)
    cor = models.CharField(max_length=10, blank=True, null=True)
    marca = models.ForeignKey(Marca, blank=True, null=True)
    curtidas_cont = models.IntegerField(blank=True, null=True)
    slug = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        db_table = 'produto'

    def get_absolute_path(self):
         return reverse('arremate:vendinha', args=[self.id, self.slug])

#
# class Leilao(models.Model):
#     leilao_id = models.IntegerField(primary_key=True)
#     produto = models.ForeignKey('Produto', blank=True, null=True)
#     data_fim = models.DateField(blank=True, null=True)
#     data_inicio = models.DateField(blank=True, null=True)
#
#     class Meta:
#         db_table = 'leilao'
#
# class PLeilao(models.Model):
#     produto_id = models.IntegerField(blank=True, null=True)
#     leilao = models.ForeignKey(Leilao, blank=True, null=True)
#
#     class Meta:
#         db_table = 'p_leilao'
#
#
# class PNormal(models.Model):
#     produto_id = models.IntegerField(blank=True, null=True)
#     preco = models.IntegerField(blank=True, null=True)
#
#     class Meta:
#         db_table = 'p_normal'
#
#
# class Tag(models.Model):
#     tag_id = models.IntegerField(primary_key=True)
#     nome = models.CharField(max_length=50, blank=True, null=True)
#
#     class Meta:
#         db_table = 'tag'
#
#
# class TagProd(models.Model):
#     produto = models.ForeignKey(Produto, primary_key=True)
#     tag = models.ForeignKey(Tag)
#
#     class Meta:
#         db_table = 'tag_prod'
#         unique_together = (('produto', 'tag'),)


# class Badge(models.Model):
#     nome_bdg = models.CharField(max_length=-1)
#     descricao_bdg = models.CharField(max_length=-1)
#     badge_id = models.IntegerField(primary_key=True)
#
#     class Meta:
#         db_table = 'badge'
#
#
# class BadgeUser(models.Model):
#     user = models.ForeignKey('Cliente')
#     badge = models.ForeignKey(Badge)
#     data_rec = models.DateField()
#
#     class Meta:
#         db_table = 'badge_user'
#
#
# class Cliente(models.Model):
#     user_id = models.IntegerField(primary_key=True)
#     user_nome = models.CharField(max_length=60, blank=True, null=True)
#     user_senha = models.CharField(max_length=8, blank=True, null=True)
#     user_email = models.CharField(max_length=60, blank=True, null=True)
#     user_ativo = models.NullBooleanField()
#
#     class Meta:
#         db_table = 'cliente'
#
#
# class Comentario(models.Model):
#     produto = models.ForeignKey('Produto', blank=True, null=True)
#     titulo = models.CharField(primary_key=True, max_length=20)
#     descricao = models.CharField(max_length=200)
#     autor = models.ForeignKey(Cliente, db_column='autor', blank=True, null=True)
#
#     class Meta:
#         db_table = 'comentario'
#         unique_together = (('titulo', 'descricao'),)
#
#
# class Estoque(models.Model):
#     estoque_id = models.IntegerField(primary_key=True)
#     loja = models.ForeignKey('Loja', blank=True, null=True)
#     produto = models.ForeignKey('Produto', blank=True, null=True)
#
#     class Meta:
#         db_table = 'estoque'
#
#
# class Foto(models.Model):
#     produto = models.ForeignKey('Produto')
#     foto_id = models.IntegerField(primary_key=True)
#     foto_content = models.CharField(max_length=-1)
#
#     class Meta:
#         db_table = 'foto'
#
#
# class Lance(models.Model):
#     data_lance = models.CharField(max_length=-1)
#     valor_lance = models.CharField(max_length=-1)
#     lance_id = models.IntegerField(primary_key=True)
#     produto = models.ForeignKey('Produto')
#     leilao = models.ForeignKey('Leilao')
#
#     class Meta:
#         db_table = 'lance'
#
#
# class LancesUser(models.Model):
#     user = models.ForeignKey(Cliente)
#     lance = models.ForeignKey(Lance)
#
#     class Meta:
#         db_table = 'lances_user'
#
#
# class Marca(models.Model):
#     marca_id = models.IntegerField(primary_key=True)
#     site = models.CharField(max_length=20, blank=True, null=True)
#     descricao = models.CharField(max_length=200, blank=True, null=True)
#
#     class Meta:
#         db_table = 'marca'
#
#
# class Seguidores(models.Model):
#     data_seg = models.CharField(max_length=-1)
#     seguidor = models.ForeignKey(Cliente)
#     user = models.ForeignKey(Cliente)
#
#     class Meta:
#         db_table = 'seguidores'
#
#
# class Vendedor(models.Model):
#     user_id = models.IntegerField()
#     user_nome = models.CharField(max_length=60, blank=True, null=True)
#     user_senha = models.CharField(max_length=8, blank=True, null=True)
#     user_email = models.CharField(max_length=60, blank=True, null=True)
#     user_ativo = models.NullBooleanField()
#     conta_deposito = models.IntegerField(blank=True, null=True)
#     seguidores = models.TextField(blank=True, null=True)  # This field type is a guess.
#     avaliacao = models.IntegerField(blank=True, null=True)
#     loja = models.ForeignKey(Loja, blank=True, null=True)
#
#     class Meta:
#         db_table = 'vendedor'
#
# class Loja(models.Model):
#     loja_id = models.IntegerField(primary_key=True)
#     nome = models.CharField(max_length=60, blank=True, null=True)
#     descricao = models.CharField(max_length=180, blank=True, null=True)
#
#     class Meta:
#         db_table = 'loja'