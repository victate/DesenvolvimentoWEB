from django.apps import AppConfig


class ArremateConfig(AppConfig):
    name = 'arremate'
