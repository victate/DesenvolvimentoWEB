# from django.http import HttpResponse
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.shortcuts import render, get_object_or_404
from .models import Produto, Foto, Loja, Imagem, PNormal, PLeilao, Leilao, Lance, Vendedor, Cliente
from carrinho.forms import FormularioParaAdicaoDeProdutosAoCarrinho
from carrinho.carrinho import Carrinho


def index(request):
    # return HttpResponse("Olá Mundo! Você está vendo o conteúdo da view index da aplicação 'vendas'")
    frase = "Olá mundo";
    return render(request, 'arremate/index.html', {'frase': frase})


def principal(request):
    carrinho = Carrinho(request)
    itens_cart = carrinho.__len__()
    if itens_cart == 0:
        itens_cart = "Carrinho de Compras"

    logo = Imagem.objects.get(imagem_id=1)
    c1 = Imagem.objects.get(imagem_id=2)
    c2 = Imagem.objects.get(imagem_id=3)
    c3 = Imagem.objects.get(imagem_id=4)
    aux = 1;
    bolsag = {"prod": Produto.objects.get(produto_id=aux),
              "preco": PNormal.objects.get(produto_id=Produto.objects.get(produto_id=aux).produto_id),
              "loja": Loja.objects.get(loja_id=Produto.objects.get(produto_id=aux).loja_id),
              "foto": Foto.objects.get(produto_id=Produto.objects.get(produto_id=aux).produto_id)}
    aux += 1;
    instaxM = {"prod": Produto.objects.get(produto_id=aux),
               "preco": PNormal.objects.get(produto_id=Produto.objects.get(produto_id=aux).produto_id),
               "loja": Loja.objects.get(loja_id=Produto.objects.get(produto_id=aux).loja_id),
               "foto": Foto.objects.get(produto_id=Produto.objects.get(produto_id=aux).produto_id)}
    aux += 1;
    relC = {"prod": Produto.objects.get(produto_id=aux),
            "preco": (PNormal.objects.get(produto_id=Produto.objects.get(produto_id=aux).produto_id)),
            "loja": Loja.objects.get(loja_id=Produto.objects.get(produto_id=aux).loja_id),
            "foto": Foto.objects.get(produto_id=Produto.objects.get(produto_id=aux).produto_id)}
    aux += 1;
    saiaF = {"prod": Produto.objects.get(produto_id=aux),
             "preco": PNormal.objects.get(produto_id=Produto.objects.get(produto_id=aux).produto_id),
             "loja": Loja.objects.get(loja_id=Produto.objects.get(produto_id=aux).loja_id),
             "foto": Foto.objects.get(produto_id=Produto.objects.get(produto_id=aux).produto_id)}
    aux += 1;
    oculosR = {"prod": Produto.objects.get(produto_id=aux),
               "leilao": Leilao.objects.get(leilao_id=
                                            PLeilao.objects.get(
                                                produto_id=Produto.objects.get(produto_id=aux).produto_id).leilao_id),
               "lances": Lance.objects.filter(produto_id=Produto.objects.get(produto_id=aux).produto_id).count(),
               "loja": Loja.objects.get(loja_id=Produto.objects.get(produto_id=aux).loja_id),
               "vendedor": Cliente.objects.get(user_id=
                                               Vendedor.objects.get(
                                                   loja_id=Produto.objects.get(produto_id=aux).loja_id).user_id_id),
               "foto": Foto.objects.get(produto_id=Produto.objects.get(produto_id=aux).produto_id)}
    aux += 1;
    macbook = {"prod": Produto.objects.get(produto_id=aux),
               "leilao": Leilao.objects.get(leilao_id=
                                            PLeilao.objects.get(
                                                produto_id=Produto.objects.get(produto_id=aux).produto_id).leilao_id),
               "lances": Lance.objects.filter(produto_id=Produto.objects.get(produto_id=aux).produto_id).count(),
               "loja": Loja.objects.get(loja_id=Produto.objects.get(produto_id=aux).loja_id),
               "foto": Foto.objects.get(produto_id=Produto.objects.get(produto_id=aux).produto_id)}
    aux += 1;
    anelG = {"prod": Produto.objects.get(produto_id=aux),
             "leilao": Leilao.objects.get(leilao_id=
                                          PLeilao.objects.get(
                                              produto_id=Produto.objects.get(produto_id=aux).produto_id).leilao_id),
             "lances": Lance.objects.filter(produto_id=Produto.objects.get(produto_id=aux).produto_id).count(),
             "loja": Loja.objects.get(loja_id=Produto.objects.get(produto_id=aux).loja_id),
             "foto": Foto.objects.get(produto_id=Produto.objects.get(produto_id=aux).produto_id)}
    aux += 1;
    livroAlice = {"prod": Produto.objects.get(produto_id=aux),
                  "leilao": Leilao.objects.get(leilao_id=
                                               PLeilao.objects.get(produto_id=Produto.objects.get(
                                                   produto_id=aux).produto_id).leilao_id),
                  "lances": Lance.objects.filter(produto_id=Produto.objects.get(produto_id=aux).produto_id).count(),
                  "loja": Loja.objects.get(loja_id=Produto.objects.get(produto_id=aux).loja_id),
                  "foto": Foto.objects.get(produto_id=Produto.objects.get(produto_id=aux).produto_id)}

    camilaL = {"foto": Imagem.objects.get(imagem_id=13),
               "lance": Lance.objects.get(lance_id=1)}
    joanaF = {"foto": Imagem.objects.get(imagem_id=14),
              "lance": Lance.objects.get(lance_id=1)}
    anaB = {"foto": Imagem.objects.get(imagem_id=15),
            "lance": Lance.objects.get(lance_id=1)}

    return render(request, 'arremate/principal.html', {
        'logo': logo,
        'c1': c1,
        'c2': c2,
        'c3': c3,
        'prod1': bolsag,
        'prod2': instaxM,
        'prod3': relC,
        'prod4': saiaF,
        'l1': oculosR,
        'l2': macbook,
        'l3': anelG,
        'l4': livroAlice,
        'user1': camilaL,
        'user2': joanaF,
        'user3': anaB,
        'itens_cart': itens_cart
    })


def exibe_produto(request, id, slug_do_produto):
    carrinho = Carrinho(request)
    itens_cart = carrinho.__len__()
    if itens_cart == 0:
        itens_cart = "Carrinho de Compras"

    produto = get_object_or_404(Produto, produto_id=id, slug=slug_do_produto)
    preco = PNormal.objects.get(produto_id=Produto.objects.get(produto_id=id).produto_id)
    foto = Foto.objects.get(produto_id=Produto.objects.get(produto_id=id).produto_id)
    logo = logo = Imagem.objects.get(imagem_id=1)
    form_adicionar_produto_carrinho = FormularioParaAdicaoDeProdutosAoCarrinho()
    return render(
        request, 'arremate/produto/vendinha.html', {'produto': produto,
                                                    "preco": preco,
                                                    "foto": foto,
                                                    "logo": logo,
                                                    'form_adicionar_produto_carrinho': form_adicionar_produto_carrinho,
                                                    "itens_cart": itens_cart})


class NewProd:
    prod = Produto
    foto = str
    loja = Loja
    preco = float

    def __init__(self, prod, foto, loja, preco):
        self.prod = prod
        self.foto = foto
        self.loja = loja
        self.preco = preco

def lista_produtos(request):
    carrinho = Carrinho(request)
    itens_cart = carrinho.__len__()
    if itens_cart == 0:
        itens_cart = "Carrinho de Compras"

    produtos = []
    logo = Imagem.objects.get(imagem_id=1)
    venda_normal = PNormal.objects.all()

    for prod in venda_normal:
        temp = NewProd(get_object_or_404(Produto, produto_id=prod.produto_id),
                                Foto.objects.get(produto_id=prod.produto_id).figura,
                                Loja.objects.get(loja_id=Produto.objects.get(produto_id=prod.produto_id).loja_id),
                                prod.preco)
        produtos.append(temp)

    paginator = Paginator(produtos, 5)
    pagina = request.GET.get('pagina')

    try:
        produtos = paginator.page(pagina)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        produtos = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        produtos = paginator.page(paginator.num_pages)


    index = produtos.number
    max_index = len(paginator.page_range)
    if max_index > 9:
        start_index = index - 3 if index > 6 else 1
        if index < 7:
            end_index = 7
        else:
            if index > 6 and index < max_index - 3:
                end_index = index + 2
            else:
                end_index = max_index-1
        if end_index > max_index - 3:
            start_index = (max_index - 7)
        page_range = paginator.page_range[start_index:end_index]
    else:
        page_range = paginator.page_range

    return render(request, 'arremate/lista.html', {"produtos": produtos,
                                                   "logo": logo,
                                                   "page_range": page_range,
                                                   "max_index": max_index,
                                                   "itens_cart": itens_cart})
