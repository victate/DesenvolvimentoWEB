contagem = 0;

$(loginSubmit).on('click', function(e) {
    e.preventDefault();

    document.getElementById("loged").textContent = "Hi, " + $(username).val();
    $(entrar).addClass("hide");
   // $(cartCont).removeClass("hide");
    $(loged).removeClass('hide');
});

$(calcFrete).on('click', function(e) {
    e.preventDefault();
    $(frete).show();
});

reset = function() {
    $(frete).hide();
    $(qntProd).val('');
    $(cep).val('');
    $(compraLogin).addClass("hide");
};

/*
$(comprar).on('click', function(e) {
    reset();
    if (!$(loged).hasClass("hide")) {
        contagem = contagem + 1;
        console.log(contagem);
        $("#addCart .close").click();
        document.getElementById("cVol").textContent = contagem;
    }
    else {
        $(compraLogin).removeClass("hide");
    }
});*/
$(cancelarComp).on('click', reset);

resetL = function() {
    $(vlrLance).val('');
    $(efetuarLanceAlert).addClass("hide");
};
$(fazerLance).on('click', function(e) {
    resetL();
    if ($(loged).hasClass("hide")) {
        $(efetuarLanceAlert).removeClass("hide");
    }else{
        $("#leilao .close").click();
    }
});
$(cancelarLance).on('click', resetL);

$(document).ready(function(){
    $(first_prod).hover(
        function(){
            $(img1).fadeTo(500,0.3);
            $(caption_prod).fadeTo(500,1.0);
        },
        function(){
            $(img1).fadeTo(500,1.0);
            $(caption_prod).fadeTo(500,0.0);
        }
    );
    $(snd_prod).hover(
        function(){
            $(img2).fadeTo(500,0.3);
            $(caption_prod2).fadeTo(500,1.0);
        },
        function(){
            $(img2).fadeTo(500,1.0);
            $(caption_prod2).fadeTo(500,0.0);
        }
    );
    $(trd_prod).hover(
        function(){
            $(img3).fadeTo(500,0.3);
            $(caption_prod3).fadeTo(500,1.0);
        },
        function(){
            $(img3).fadeTo(500,1.0);
            $(caption_prod3).fadeTo(500,0.0);
        }
    );
    $(fth_prod).hover(
        function(){
            $(img4).fadeTo(500,0.3);
            $(caption_prod4).fadeTo(500,1.0);
        },
        function(){
            $(img4).fadeTo(500,1.0);
            $(caption_prod4).fadeTo(500,0.0);
        }
    );
});

$('body').scrollspy({ target: '#navbar' })


$(function() {
    $('[data-toggle="tooltip"]').tooltip();
});

$(function() {
    $('[data-toggle="popover"]').popover();
});


