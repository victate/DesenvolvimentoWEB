# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from __future__ import unicode_literals

from django.db import models
from django.urls import reverse


class Loja(models.Model):
    loja_id = models.IntegerField(primary_key=True)
    nome = models.CharField(max_length=60, blank=True, null=True)
    descricao = models.CharField(max_length=180, blank=True, null=True)


class Marca(models.Model):
    marca_id = models.IntegerField(primary_key=True)
    nome = models.CharField(max_length=20, blank=False, null=False)
    site = models.CharField(max_length=20, blank=True, null=True)
    descricao = models.CharField(max_length=200, blank=True, null=True)

class Produto(models.Model):
    produto_id = models.IntegerField(primary_key=True)
    nome = models.CharField(max_length=60, blank=True, null=True)
    descricao = models.CharField(max_length=180, blank=True, null=True)
    loja = models.ForeignKey(Loja, blank=True, null=True)
    tamanho = models.IntegerField(blank=True, null=True)
    cor = models.CharField(max_length=10, blank=True, null=True)
    marca = models.ForeignKey(Marca, blank=True, null=True)
    curtidas_cont = models.IntegerField(blank=True, null=True)
    slug = models.CharField(max_length=50, blank=True, null=True)

    def __str__(self):
        return self.nome

    def get_absolute_path(self):
        return reverse('arremate:exibe_produto', args=[self.produto_id, self.slug])

class Leilao(models.Model):
    leilao_id = models.IntegerField(primary_key=True)
    produto = models.ForeignKey('Produto', blank=True, null=True)
    data_fim = models.DateField(blank=True, null=True)
    data_inicio = models.DateField(blank=True, null=True)

class PLeilao(models.Model):
    produto_id = models.IntegerField(blank=True, null=True)
    leilao = models.ForeignKey(Leilao, blank=True, null=True)


class PNormal(models.Model):
    produto_id = models.IntegerField(blank=True, null=True)
    preco = models.IntegerField(blank=True, null=True)

class Tag(models.Model):
    tag_id = models.IntegerField(primary_key=True)
    nome = models.CharField(max_length=50, blank=True, null=True)
    slug = models.CharField(max_length=50, blank=False, null=False)

    def __str__(self):
        return self.nome

    def get_absolute_path(self):
        return reverse('arremate:lista_produtos_por_tag', args=[self.slug])



class TagProd(models.Model):
    produto = models.ForeignKey(Produto, primary_key=True)
    tag = models.ForeignKey(Tag)

    class Meta:
        unique_together = (('produto', 'tag'),)


class Badge(models.Model):
    nome_bdg = models.CharField(max_length=100)
    descricao_bdg = models.CharField(max_length=100)
    badge_id = models.IntegerField(primary_key=True)


class BadgeUser(models.Model):
    user = models.ForeignKey('Cliente')
    badge = models.ForeignKey(Badge)
    data_rec = models.DateField()


class Cliente(models.Model):
    user_id = models.IntegerField(primary_key=True)
    user_nome = models.CharField(max_length=60, blank=True, null=True)
    user_senha = models.CharField(max_length=8, blank=True, null=True)
    user_email = models.CharField(max_length=60, blank=True, null=True)
    user_ativo = models.NullBooleanField()



class Comentario(models.Model):
    produto = models.ForeignKey('Produto', blank=True, null=True)
    titulo = models.CharField(primary_key=True, max_length=20)
    descricao = models.CharField(max_length=200)
    autor = models.ForeignKey(Cliente, db_column='autor', blank=True, null=True)

    class Meta:
        unique_together = (('titulo', 'descricao'),)


class Estoque(models.Model):
    estoque_id = models.IntegerField(primary_key=True)
    loja = models.ForeignKey('Loja', blank=True, null=True)
    produto = models.ForeignKey('Produto', blank=True, null=True)



class Foto(models.Model):
    produto = models.ForeignKey('Produto')
    nome = models.CharField(max_length=30, null=False)
    foto_id = models.IntegerField(primary_key=True)
    figura = models.ImageField()

class Imagem(models.Model):
    imagem_id = models.IntegerField(primary_key=True)
    nome = models.CharField(max_length=30, null=False)

class Lance(models.Model):
    data_lance = models.CharField(max_length=20)
    valor_lance = models.CharField(max_length=10000)
    lance_id = models.IntegerField(primary_key=True)
    produto = models.ForeignKey('Produto')
    leilao = models.ForeignKey('Leilao')



class LancesUser(models.Model):
    user = models.ForeignKey(Cliente)
    lance = models.ForeignKey(Lance)


class Seguidores(models.Model):
    data_seg = models.CharField(max_length=20)
    seguidor = models.ForeignKey(Cliente, related_name="seguidor")
    seguido = models.ForeignKey(Cliente, related_name="seguido")



class Vendedor(models.Model):
    user_id = models.ForeignKey('Cliente', primary_key=True)
    conta_deposito = models.IntegerField(blank=True, null=True)
    seguidores = models.TextField(blank=True, null=True)  # This field type is a guess.
    avaliacao = models.IntegerField(blank=True, null=True)
    loja = models.ForeignKey(Loja, blank=True, null=True)

