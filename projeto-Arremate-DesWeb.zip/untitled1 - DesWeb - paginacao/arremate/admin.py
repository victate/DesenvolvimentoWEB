from django.contrib import admin
from .models import Tag, Produto

class TagAdmin(admin.ModelAdmin):
    list_display = ['nome', 'slug']
    prepopulated_fields = {'slug': ('nome',)}
admin.site.register(Tag, TagAdmin)

class ProdutoAdmin(admin.ModelAdmin):
    list_display = ['nome', 'slug', 'descricao', 'loja', 'tamanho', 'cor', 'marca']
    list_filter = ['loja', 'marca']
    list_editable = ['descricao', 'tamanho', 'cor', 'marca']
    prepopulated_fields = {'slug': ('nome',)}
    fields = ('nome', 'slug', 'descricao', 'loja', 'marca', 'tamanho', 'cor')
admin.site.register(Produto, ProdutoAdmin)