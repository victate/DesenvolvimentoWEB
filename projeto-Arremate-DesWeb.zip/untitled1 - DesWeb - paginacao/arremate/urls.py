from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.principal, name='principal'),
    url(r'^(?P<id>\d+)/(?P<slug_do_produto>[-\w]+)/$', views.exibe_produto, name='exibe_produto'),
    url(r'^all/', views.lista_produtos, name='lista_produtos'),
]
