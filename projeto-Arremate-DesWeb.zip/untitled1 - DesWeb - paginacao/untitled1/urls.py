from django.conf.urls import include, url
from django.contrib import admin

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^carrinho/', include('carrinho.urls', namespace='carrinho')),
    url(r'^', include('arremate.urls', namespace='arremate')),
]